import random

class Satici:
    """
    Satıcı sınıfı oluşturdum.

    Attributes:
        satici_no (int): Satıcının numarası.
        talep (int): Satıcının talep miktarı.
    """
    def __init__(self, satici_no, talep):
        self.satici_no = satici_no
        self.talep = talep

# değişken sabitleri oluşturdum
sayi_saticilar = 10  # Toplam satıcı sayısı
depo_stok = 1000     # Depodaki başlangıç stok miktarı

# Satıcılar listesi oluştur ve talep miktarlarını ata
saticilar_listesi = []
for i in range(1, sayi_saticilar + 1):
    talep = random.randint(1, 100)  # Her satıcı için 1 ile 100 arasında rastgele talep oluşturdum
    satici = Satici(i, talep)
    saticilar_listesi.append(satici)

# Siparişleri dosyaya yazdım
with open("siparisler.txt", "w") as out_file:
    out_file.write("Bayi_No Address Talep_Sayisi\n")  # Dosya başlığı
    for satici in saticilar_listesi:
        out_file.write(f"{satici.satici_no} {id(satici)} {satici.talep}\n")

    # Satıcılar listesini karıştırdım ve yazdırdım
    random.shuffle(saticilar_listesi)  # Satıcı listesini rastgele sıraladım

    out_file.write("------------------------------\n")
    out_file.write(" Belirlenen Dağitim Rotasi\n")
    out_file.write("------------------------------\n")

    for satici in saticilar_listesi:
        out_file.write(f"{satici.satici_no} {id(satici)} {satici.talep}\n")

# Ekrana yazdırdım
for satici in saticilar_listesi:
    print(f"{satici.satici_no} {id(satici)} {satici.talep}")

# Satıcılar listesindeki talepleri topladım ve kalan stok miktarını hesapladım
kalan_stok = depo_stok
for satici in saticilar_listesi:
    kalan_stok -= satici.talep  # Talep edilen miktarı toplam stoktan çıkardım

# Ekrana ve dosyaya kalan stok miktarını yazdım
print("******************************")
print(f"Kalan miktar: {kalan_stok}")

with open("siparisler.txt", "a") as out_file:
    out_file.write("******************************\n")
    out_file.write(f"Kalan miktar: {kalan_stok}\n")
